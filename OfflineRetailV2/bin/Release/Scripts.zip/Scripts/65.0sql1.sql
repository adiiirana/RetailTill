ALTER TABLE [dbo].[Setup]
ADD [POSShowBalanceDialog] [int] NULL
GO